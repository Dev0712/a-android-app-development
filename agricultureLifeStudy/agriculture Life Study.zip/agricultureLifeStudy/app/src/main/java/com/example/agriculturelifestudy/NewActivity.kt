package com.example.agriculturelifestudy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class NewActivity : AppCompatActivity(), View.OnClickListener {

        lateinit var etMobileNumber:EditText
        lateinit var etPassword:EditText
        lateinit var etName:EditText
        lateinit var btnLogin:Button
        lateinit var txtForgotPassword:TextView
        lateinit var txtRegister:TextView

    override fun onCreate(savedInstanceState: Bundle?) {

        val validMobileNumber="8302571961"
        val validPassword="Dev@0712"
        val validName= arrayOf("Devendra","Narendra","jyoti","maya","Ramji lal raiger")

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new)

        title = "Log In"



        etMobileNumber=findViewById(R.id.etMobileNumber)
        etPassword=findViewById(R.id.etPassword)
        etName=findViewById(R.id.etName)
        btnLogin=findViewById(R.id.btnLogin)
        txtForgotPassword=findViewById(R.id.txtForgotPassword)
        txtRegister = findViewById(R.id.txtRegister)

        btnLogin.setOnClickListener {
            val MobileNumber = etMobileNumber.text.toString()

            val Password = etPassword.text.toString()

            val personName = etName.text.toString()

            val intent = Intent(this@NewActivity,MainActivity::class.java)



            if ((MobileNumber == validMobileNumber) && (Password == validPassword) && ( validName.contains(personName)))
            {
                startActivity (intent)
                intent.putExtra(name:"Name",PersonName)}
            else
            {
                Toast.makeText(
                    this@NewActivity,
                    "Incorrect credentials",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        }

    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }

}